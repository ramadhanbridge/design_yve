<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Document</title>
	<link rel="stylesheet" href="public/css/btstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
	<link rel="stylesheet" href="public/css/mycss.css">
	<link rel="stylesheet" href="public/css/anmt.css">
	<script src="public/js/jquery.js"></script>
	<script src="public/js/btstrap.js"></script>
	<script src="public/js/myjs.js"></script>
	<script src="https://unpkg.com/scrollreveal"></script>
    <script>
    	$(function(){
  $("#show_signup_form").click(function(){  
   $("#signup_hide").show();
   $("#sign_in").hide();
})

 $("#show_sign").click(function(){  
   $("#signup_hide").hide();
   $("#sign_in").show();
})

  });

    </script>
</head>
 <body>

 <div class="row ">

   <div class="col-md-8 log_style">
     <div class="row">

       <div class="col-md-12"><h1 class="lgtext">LEARN CITY</h1></div>

       <div class="col-md-8 log_style2 slideOutUp" >
         Put your creative energy <br> in mastering concepts,<br>  
rather than getting<br>  
test-scores. 
       </div>
     </div>
   </div>

   <div class="col-md-4" >


     <section><div class="row animated fadeInRight form-spc" id="sign_in">
     	<div class="col-md-12"><h1>	Login</h1><span><a id="show_signup_form">Or Create Account</a></span></div>
     	<div class="col-md-12">
     		<form action="/action_page.php">
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd">
  </div>
  <div class="checkbox">
    <label><input type="checkbox">By signing in you agreeto our services<br>  terms and conditions</label>
  </div>
  
  <button type="submit" class="btn btn-default">Submit</button>
</form>
     	</div>
     </div>
     	
     </section>



      <section><div class="row animated fadeInRight form-spc"  id="signup_hide">
     	<div class="col-md-12"><h1>	SIGN UP</h1><span><a id="show_sign">Or Sign in your Account</a></span></div>
     	<div class="col-md-12">
     		<form action="/action_page.php">
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd">
  </div>
  <div class="checkbox">
    <label><input type="checkbox">By signing in you agreeto our services<br>  terms and conditions</label>
  </div>
  
  <button type="submit" class="btn btn-default">Submit</button>
</form>
     	</div>
     </div>
     	
     </section>




   </div>
 </div>


 </body>
</html>