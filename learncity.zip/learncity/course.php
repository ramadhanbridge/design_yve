<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Document</title>
	<link rel="stylesheet" href="public/css/btstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
	<link rel="stylesheet" href="public/css/mycss.css">
	<link rel="stylesheet" href="public/css/anmt.css">
	<script src="public/js/jquery.js"></script>
	<script src="public/js/btstrap.js"></script>
	<script src="public/js/myjs.js"></script>

	<script src="https://unpkg.com/scrollreveal"></script>
	<script>
$(document).ready(function(){
  $(window).scroll(function(){
  	var scroll = $(window).scrollTop();
	  if (scroll > 200) {
	   $('.navbar').addClass('blackBg');
	  }

	  else{
		  $(".navbar").removeClass('blackBg');  	
	  }
  })
})</script>
</head>
 <body>

 	<section>
<nav class="navbar navbar-inverse" id="course_nav">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#" style="color: white;font-size: 30px">LEARN CITY</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" style="padding-left: 20px">
        
        <li><a href="#" style="color: white">LESSONS</a></li>
        <li><a href="#" style="color: white">PRACTICE</a></li>
        <li><a href="#" style="color: white">CITY COUNCIL</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        
        <li>
        	<div class="row">
        		<div class="col-md-4 paccount_owner"></div>
        		<div class="col-md-4" style="color: white;font-size: 14px">Mugenga Yve</div>
        	</div>
        </li>
      </ul>
    </div>
  </div>
</nav>
</section>
  
  <section>
  	<div class="spc7" >
  		<div class="row" style="margin: 0 auto">
  			<div class="col-md-8">
  			<div class="row">
  				<div class="col-md-4">
  					<div class="course_owner"></div>
  				</div>
  				<div class="col-md-8">
  					<h3>MUGENGA</h3><br>
  					<span>L.V 45</span>
  				</div>
  			</div>
  		</div>
  		</div>
  	</div>
  </section>

<section>
  	<div  id="spc8">
  		<div class="row" style="margin: 0 auto;padding-bottom: 4px !important">
  				<div class="col-md-8">
  					<p style="font-size: 22px;color: #1a445d ">Keep working where you left of<br>
  					<span style="font-weight: bold;">Introduction to statistics</span></p>
  				</div>
  				<div class="col-md-4" style="display: flex !important">
  					
  					<button class="resume" >Resume</button>
  				</div>
  		</div>
  	</div>

  </section>

<section>
	<div class="row">
		<div class="col-md-12"><div style="width: 25%;margin: 20px auto;text-align: center"><h3>LESSONS IN PROGRESS</h4></div></div>

<?php for ($i=0; $i <6 ; $i++) { ?>
  		<div class="col-md-3">
  			<div class="courses_progress">
  				<h2 class="spc3">Intoduction<br>to logic</h2>
  			</div>
  		</div>
         <?php }?>
     </div>


     <div class="row"  style="margin-bottom: 40px !important">
		<div class="col-md-12"><div style="width: 25%;margin: 20px auto;text-align: center;"><h3>FINISHED COURSE</h4></div></div>

<?php for ($i=0; $i <4 ; $i++) { ?>
  		<div class="col-md-3">
  			<div class="courses_progress">
  				<h2 class="spc3">Intoduction<br>to logic</h2>
  			</div>
  		</div>
         <?php }?>
     </div>
	

</section>
<script src="public/js/myjs.js"></script>
	<script type="text/javascript">
		$("#fittext1").fitText();
		$("#fittext2").fitText(1.2);
		$("#fittext3").fitText(1.2, { minFontSize: '20px', maxFontSize: '50px' });
	</script>

 </body>
</html>