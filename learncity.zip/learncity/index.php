<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Document</title>
	<link rel="stylesheet" href="public/css/btstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
	<link rel="stylesheet" href="public/css/mycss.css">
		<link rel="stylesheet" href="public/css/anmt.css">
	<script src="public/js/jquery.js"></script>
	<script src="public/js/btstrap.js"></script>
	<script src="public/js/myjs.js"></script>

	<script src="https://unpkg.com/scrollreveal"></script>
	<script>
$(document).ready(function(){
  $(window).scroll(function(){
  	var scroll = $(window).scrollTop();
	  if (scroll > 200) {
	   $('.navbar').addClass('blackBg');
	  }

	  else{
		  $(".navbar").removeClass('blackBg');  	
	  }
  })
})</script>
</head>
 <body>
  <section >
	<div class="row" id="home_backg" >
	
			 <nav class="navbar navbar-inverse navbar-default ">
				  <div class="container-fluid">

				    <div class="navbar-header">
				      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				      </button>

				      <a class="navbar-brand lgtext" href="#">LEARN CITY</a>
				    </div>

				    <div class="collapse navbar-collapse" id="myNavbar">
				      <ul class="nav navbar-nav navbar-right">
				        <li><a href="#" class="mdtext"> LOGIN</a></li>
				        <li><a href="#" class="mdtext slideOutUp" id="box_link"> SIGN UP FOR FREE</a></li>
				      </ul>
				    </div>

				  </div>
             </nav>


             <!-- content -->
             <div class="spc1" >
             	<span class="spc2">The smartest way to</span>

             	<div class="mdtext_ex " id="equalize fit" style="margin-bottom: 22px !important;">
             		<h1 id="fittext3" >Learn skills for building<br>  
                    tomorrow and, beyond </h1>
             		
             	</div>


             	<a href="#" class="mdtext" id="box_link2">Start learning for free</a>
             </div>
		
		
	</div>
  </section>

 
  <section>
  	<div class="box_center">
  		<div class="  box_center_chd "> A Groundbreaking<br> Learning Experience
  			
  		</div>
  		<div id="under_line"></div>
  	</div>

  	<div class="row row_back">
  		<div class="">
  		  <div class="box_center_chd2 "> Featured Course
  			
  		  </div>
  		   <div id="under_line2"></div>
  	    </div>
  		<?php for ($i=0; $i <3 ; $i++) { ?>
  		<div class="col-md-4">
  			<div class="courses">
  				<h2 class="spc3">Intoduction<br>to logic</h2>
  			</div>
  		</div>
         <?php }?>
  	</div>
  	
  </section>



  <section>
  	<div class="row spc4" >
  		<div class="col-md-6" style="padding: 5%;padding-bottom: 0px !important;">
  			<div id="under_line2">
  			</div>
  			<div class="mdtext3">Join thousands of <br> 
others learning <br>
on LearnCity
  		   </div>
  	    </div>
  		<div class="col-md-6" id="join">
  			
  		</div>
  	</div>
</section>


<section>
  	<div class="row spc4" >
  		<div class="col-md-6" id="join">
  			
  		</div>
  		<div class="col-md-6" style="padding: 5% !important;padding-bottom: 0px !important;">
  			
  			<div class="mdtext3 pull-right text_just">
  				<div id="under_line2"  class="pull-right" >
  			</div><br>Join thousands of <br> 
others learning <br>
on LearnCity<br>
 <a href="" class="spc5">START PRACTING</a>

     </div>
    
  	    </div>
  		
  	</div>
</section>


<!-- footer -->
<section>
<div class="row ft_style" >
	<div class="col-md-4"><div class="lgtext">LEARN CITY</div></div>
	<div class="col-md-2 spc6"><div>LEARN city2018</div></div>
	<div class="col-md-2 spc6"><div>privacy police</div></div>
	<div class="col-md-2 spc6"><div>terms of use</div></div>
	<div class="col-md-2 spc6">
		<div class="row">
			<div class="col-md-4"><i class="fa fa-facebook"></i></div>
			<div class="col-md-4"><i class="fa fa-facebook"></i></div>
			<div class="col-md-4"><i class="fa fa-facebook"></i></div>
		</div>
	</div>
</div>
</section>


<script src="public/js/myjs.js"></script>
	<script type="text/javascript">
		$("#fittext1").fitText();
		$("#fittext2").fitText(1.2);
		$("#fittext3").fitText(1.2, { minFontSize: '20px', maxFontSize: '50px' });
	</script>

 </body>
</html>