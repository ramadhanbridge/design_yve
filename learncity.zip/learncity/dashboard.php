<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Document</title>
	<link rel="stylesheet" href="public/css/btstrap.css">
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
	<link rel="stylesheet" href="public/css/mycss.css">
	<link rel="stylesheet" href="public/css/anmt.css">
	<script src="public/js/jquery.js"></script>
	<script src="public/js/btstrap.js"></script>
	<script src="public/js/myjs.js"></script>

	<script src="https://unpkg.com/scrollreveal"></script>
	<script>
$(document).ready(function(){
  $(window).scroll(function(){
  	var scroll = $(window).scrollTop();
	  if (scroll > 200) {
	   $('.navbar').addClass('blackBg');
	  }

	  else{
		  $(".navbar").removeClass('blackBg');  	
	  }
  })
})</script>
</head>
 <body>
<section>
<nav class="navbar navbar-inverse" id="course_nav">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#" style="color: white;font-size: 30px">LEARN CITY</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" style="padding-left: 20px">
        
        <li><a href="#" style="color: white">LESSONS</a></li>
        <li><a href="#" style="color: white">PRACTICE</a></li>
        <li><a href="#" style="color: white">CITY COUNCIL</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        
        <li>
          <div class="row">
            <div class="col-md-4 paccount_owner"></div>
            <div class="col-md-4" style="color: white;font-size: 14px">Mugenga Yve</div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</nav>
</section>
  

  <section>
    <div class="row" style="margin-top: 5% !important">
      <div class="col-md-2">
        <h3>CONTENTS</h3>
          <ul style="padding: 0 !important">
          <li style="list-style: none;" class="course_outline_active"><div><h4 style="margin-bottom: 10px">Basic concepts</h4></div>
          </li>
          <li style="list-style: none;" class="course_outline"><div class="text_style"><h4 style="margin-bottom: 10px">Basic concepts</h4></div>
          </li>
          <li style="list-style: none;" class="course_outline"><div class="text_style"><h4 style="margin-bottom: 10px">Basic concepts</h4></div>
          </li>
          <li style="list-style: none;" class="course_outline"><div class="text_style"><h4 style="margin-bottom: 10px">Basic concepts</h4></div>
          </li>
          </ul>
      </div>
        <div class="col-md-10">
          <div class="row"><div class="col-md-12"><h3 style="margin-bottom: 10px"> INTRODUCTION TO TRIGONOMETRY </h3> <div id="player"></div></div>
        </div>
         <div class="col-md-12">
           <h4>EXERCISES</h4>
           <div id="under_line3">
        </div>

         </div>
    <div class="col-md-10" style="background: white ;margin-top: 30px;padding-bottom: 30px">
      <h3>QUESTION 1</h3>
      <p> what is the Lorem ipsum dolor sit amet, consectetur adipisicing elit. Saepe, fugit.?</p>
     <div class="row">
       <div class="col-md-12">
          <div>
        
   <div style="width: 80% !important ">
    <input type="checkbox" class="checkbox-circle" />
    <label for="checkbox"> </label>
    <span style="margin-left: 4%"> what is blradjfdhbjkasdfkjjk Lorem ipsum dolor sit amet, </span>
   </div>
  

    </div>
    <div class="row">
      <div class="col-md-3"><button class="resume" >next</button></div>
       <div class="col-md-3"><button class="resume" >prev</button></div>
    </div>
       </div>
     </div>
    </div>

        </div>
    </div>
  </section>
<script src="public/js/myjs.js"></script>
	 <script type="text/javascript">
		$("#fittext1").fitText();
		$("#fittext2").fitText(1.2);
		$("#fittext3").fitText(1.2, { minFontSize: '20px', maxFontSize: '50px' });
	</script>
  <script>
      // 2. This code loads the IFrame Player API code asynchronously.
      var tag = document.createElement('script');

      tag.src = "https://www.youtube.com/iframe_api";
      var firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

      // 3. This function creates an <iframe> (and YouTube player)
      //    after the API code downloads.
      var player;
      function onYouTubeIframeAPIReady() {
        player = new YT.Player('player', {
          height: '390',
          width: '900',
          videoId: 'M7lc1UVf-VE',
          events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange
          }
        });
      }

      // 4. The API will call this function when the video player is ready.
      function onPlayerReady(event) {
        event.target.playVideo();
      }

      // 5. The API calls this function when the player's state changes.
      //    The function indicates that when playing a video (state=1),
      //    the player should play for six seconds and then stop.
      var done = false;
      function onPlayerStateChange(event) {
        if (event.data == YT.PlayerState.PLAYING && !done) {
          setTimeout(stopVideo, 6000);
          done = true;
        }
      }
      function stopVideo() {
        player.stopVideo();
      }
    </script>


 </body>
</html>